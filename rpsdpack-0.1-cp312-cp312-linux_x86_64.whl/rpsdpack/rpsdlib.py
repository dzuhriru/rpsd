import cython
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy.linalg import expm

def rpsd_plt(A,Sesi,Nama,NIU,NIF):
  # Membaca Titik-Titik Data dari File Text
  Npts = 361
  f = open('RPSD_PLT_'+ Sesi +'_' + str(NIU) + '.txt', "r")
  V = np.zeros((3,Npts))
  W = np.zeros((3,Npts))
  for i in range(0,Npts):
    V[0,i] = float(f.readline())
    V[1,i] = float(f.readline())
    V[2,i] = 1
  for i in range(0,Npts):
    W[0,i] = float(f.readline())
    W[1,i] = float(f.readline())
    W[2,i] = 1
  f.close()

  # Menghitung Titik-Titik Data Hasil Transformasi
  Z = A@V

  # Menampilkan Grafik
  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=V[0,:],y=V[1,:], mode="lines", name='Original Shape'),
              row=1, col=1)
  fig.add_trace(go.Scatter(x=W[0,:],y=W[1,:], mode="lines", name='Target Shape'),
              row=1, col=1)
  fig.add_trace(go.Scatter(x=Z[0,:],y=Z[1,:], mode="lines", name='Current Shape'),
              row=1, col=1)
  fig.update_yaxes(scaleanchor="x",
                  scaleratio=1)
  fig.update_layout(height=600, width=700,
                  title_text="Linear Transformation")
  fig.show()

  # Proses Penyimpanan Data
  f = open("RPSD_PLT_Hasil_"+Sesi+"_"+str(NIU)+"_"+str(NIF)+"_"+Nama+".txt", "w")
  f.write(Nama + "\n")
  f.write(str(NIU) + "\n")
  f.write(str(NIF) + "\n")
  f.write(Sesi + "\n")
  for row in range (0,3):
    for col in range (0,3):
      f.write(str(A[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(W[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(Z[row,col]) + "\n")
  f.close()

def rpsd_dync(A,Sesi,Nama,NIU,NIF):
  # Membaca Titik-Titik Data dari File Text
  Npts = 2001
  Tsamp = 0.01
  f = open('RPSD_DYNC_'+ Sesi +'_' + str(NIU) + '.txt', "r")
  K = np.zeros((1,Npts))
  X1 = np.zeros((2,Npts))
  X2 = np.zeros((2,Npts))
  X3 = np.zeros((2,Npts))
  for i in range(0,Npts):
    K[0,i] = float(f.readline())
    X3[1,i] = float(f.readline())
    X2[0,i] = float(f.readline())
    X2[1,i] = float(f.readline())
    X1[0,i] = float(f.readline())
    X1[1,i] = float(f.readline())
    X3[0,i] = float(f.readline())
  f.close()

  # Menghitung Titik-Titik Data Hasil Transformasi
  V1 = np.zeros((2,Npts))
  V2 = np.zeros((2,Npts))
  V3 = np.zeros((2,Npts))
  V1[:,0] = X1[:,0]
  V2[:,0] = X2[:,0]
  V3[:,0] = X3[:,0]
  Ad = expm(A*Tsamp)
  for i in range(1,Npts):
    V1[:,i] = Ad@V1[:,i-1]
    V2[:,i] = Ad@V2[:,i-1]
    V3[:,i] = Ad@V3[:,i-1]

  # Menampilkan Grafik
  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X1[0,:], mode="lines", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X1[1,:], mode="lines", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V1[0,:], mode="lines", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V1[1,:], mode="lines", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 1")
  fig.show()

  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X2[0,:], mode="lines", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X2[1,:], mode="lines", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V2[0,:], mode="lines", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V2[1,:], mode="lines", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 2")
  fig.show()

  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X3[0,:], mode="lines", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X3[1,:], mode="lines", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V3[0,:], mode="lines", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V3[1,:], mode="lines", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 3")
  fig.show()

  # Proses Penyimpanan Data
  f = open("RPSD_DYNC_Hasil_"+Sesi+"_"+str(NIU)+"_"+str(NIF)+"_"+Nama+".txt", "w")
  f.write(Nama + "\n")
  f.write(str(NIU) + "\n")
  f.write(str(NIF) + "\n")
  f.write(Sesi + "\n")
  for row in range (0,2):
    for col in range (0,2):
      f.write(str(A[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X1[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X2[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X3[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V1[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V2[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V3[row,col]) + "\n")
  f.close()

def rpsd_dynd(A,Sesi,Nama,NIU,NIF):
  # Membaca Titik-Titik Data dari File Text
  Npts = 21
  f = open('RPSD_DYND_'+ Sesi +'_' + str(NIU) + '.txt', "r")
  K = np.zeros((1,Npts))
  X1 = np.zeros((2,Npts))
  X2 = np.zeros((2,Npts))
  X3 = np.zeros((2,Npts))
  for i in range(0,Npts):
    K[0,i] = float(f.readline())
    X1[0,i] = float(f.readline())
    X2[1,i] = float(f.readline())
    X2[0,i] = float(f.readline())
    X3[1,i] = float(f.readline())
    X3[0,i] = float(f.readline())
    X1[1,i] = float(f.readline())
  f.close()

  # Menghitung Titik-Titik Data Hasil Transformasi
  V1 = np.zeros((2,Npts))
  V2 = np.zeros((2,Npts))
  V3 = np.zeros((2,Npts))
  V1[:,0] = X1[:,0]
  V2[:,0] = X2[:,0]
  V3[:,0] = X3[:,0]
  for i in range(1,Npts):
    V1[:,i] = A@V1[:,i-1]
    V2[:,i] = A@V2[:,i-1]
    V3[:,i] = A@V3[:,i-1]

  # Menampilkan Grafik
  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X1[0,:], mode="lines+markers", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X1[1,:], mode="lines+markers", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V1[0,:], mode="lines+markers", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V1[1,:], mode="lines+markers", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 1")
  fig.show()

  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X2[0,:], mode="lines+markers", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X2[1,:], mode="lines+markers", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V2[0,:], mode="lines+markers", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V2[1,:], mode="lines+markers", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 2")
  fig.show()

  subplots = []
  fig = make_subplots(
      rows=1, cols=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X3[0,:], mode="lines+markers", name='Target (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=X3[1,:], mode="lines+markers", name='Target (Component 2)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V3[0,:], mode="lines+markers", name='Current (Component 1)'),
                row=1, col=1)
  fig.add_trace(go.Scatter(x=K[0,:],y=V3[1,:], mode="lines+markers", name='Current (Component 2)'),
                row=1, col=1)
  fig.update_layout(height=600, width=1000,
                    title_text="Initial Condition 3")
  fig.show()

  # Proses Penyimpanan Data
  f = open("RPSD_DYND_Hasil_"+Sesi+"_"+str(NIU)+"_"+str(NIF)+"_"+Nama+".txt", "w")
  f.write(Nama + "\n")
  f.write(str(NIU) + "\n")
  f.write(str(NIF) + "\n")
  f.write(Sesi + "\n")
  for row in range (0,2):
    for col in range (0,2):
      f.write(str(A[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X1[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X2[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(X3[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V1[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V2[row,col]) + "\n")
  for col in range (0,Npts):
    for row in range (0,2):
      f.write(str(V3[row,col]) + "\n")
  f.close()